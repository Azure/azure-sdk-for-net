﻿namespace Microsoft.Azure.Management.V2.Resource.Core
{
    public interface IIndexable
    {
        string Key { get; }
    }
}
