﻿using Microsoft.Rest.Azure;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Microsoft.Azure.Management.V2.Resource.Core
{
    public abstract class ReadableWrappers<IFluentResourceT, FluentResourceT, InnerResourceT>
    {
        protected abstract IFluentResourceT wrapModel(InnerResourceT inner);

        protected PagedList<IFluentResourceT> WrapList(PagedList<InnerResourceT> pagedList)
        {
            return new PagedList<IFluentResourceT>(new WrappedPage<InnerResourceT, IFluentResourceT>(pagedList.CurrentPage, wrapModel),
                (string nextLink) =>
                {
                    pagedList.LoadNextPage();
                    return new WrappedPage<InnerResourceT, IFluentResourceT>(pagedList.CurrentPage, wrapModel);
                });
        }

        protected class WrappedPage<InnerT, WrappedT> : IPage<WrappedT>
        {
            private string nextPageLink;
            private List<WrappedT> wrappedPageItems;

            public WrappedPage(IPage<InnerT> innerPage, Func<InnerT, WrappedT> doWrap)
            {
                wrappedPageItems = innerPage.Select(doWrap).ToList();
                nextPageLink = innerPage.NextPageLink;
            }

            public string NextPageLink
            {
                get
                {
                    return nextPageLink;
                }
            }

            public IEnumerator<WrappedT> GetEnumerator()
            {
                return wrappedPageItems.GetEnumerator();
            }

            IEnumerator IEnumerable.GetEnumerator()
            {
                return GetEnumerator();
            }
        }
    }
}
