# Generated code configuration

Run `dotnet build /t:GenerateTest` to generate code.

# Azure.ResourceManager.LiftrQumulo.Tests

> see https://aka.ms/autorest
``` yaml
require: ../src/autorest.md
include-x-ms-examples-original-file: true
testgen:
  sample: true
```