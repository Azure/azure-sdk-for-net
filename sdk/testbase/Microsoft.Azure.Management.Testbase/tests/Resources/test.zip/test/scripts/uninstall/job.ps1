# UnInstall Script
# Smoke Test imitating app crash.

Write-Host "Application in Uninstall Stage"
$scriptFolder = Split-Path $script:MyInvocation.MyCommand.Path
$appFolder = (get-item $scriptFolder).Parent.Parent.FullName
$msiExec = "msiexec.exe"
$msiFile = Join-Path $appFolder "bin\USLTestApps.msi"
$msiLogFolder = Join-Path $scriptFolder "logs"
if ($false -eq (Test-Path $msiLogFolder)) {
    New-Item -Path $msiLogFolder -ItemType Directory -Force | Out-Null
}
$msiLogName = "USLTestApps_{0}.log" -f $((get-date).ToUniversalTime().ToString("yyyyMMddThhmmssZ"))
$msiLog = Join-Path $msiLogFolder $msiLogName
$msiArgs = "/x `"$msiFile`" /qn /norestart /l*v `"$msiLog`""

Write-Host "Running command:"
Write-Host "Start-Process $msiExec -ArgumentList $msiArgs -Wait -PassThru -NoNewWindow"
$process = Start-Process $msiExec -ArgumentList $msiArgs -Wait -PassThru -NoNewWindow 
if ($null -eq $process) {
    Write-Error "Could not start process $msiExec."
    $exitCode = -1
}
else {
    $exitCode = $process.ExitCode
    Write-Host "$msiExec returned exit code: $exitCode"
}
return $exitCode