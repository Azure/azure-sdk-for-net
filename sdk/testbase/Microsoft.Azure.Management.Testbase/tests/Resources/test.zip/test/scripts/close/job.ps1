# Close Script
# Smoke Test imitating app crash.

Write-Host "Application in Close Stage"
Write-Host "Close Stage Has No Operation"

return 0