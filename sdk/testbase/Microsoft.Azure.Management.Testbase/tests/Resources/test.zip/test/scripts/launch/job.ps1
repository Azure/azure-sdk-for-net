# Launch Script
# Smoke Test imitating app crash.

Write-Host "Application in Launch Stage"
$installFolder =  ${Env:ProgramFiles}
$crashingApp = Join-Path $installFolder "Microsoft\USL\USLTestApps\USLTestCrash.exe" 

Write-Host "Running command:"
Write-Host "Start-Process $crashingApp -Wait -PassThru -NoNewWindow"
$process = Start-Process $crashingApp -Wait -PassThru -NoNewWindow 
if ($null -eq $process) {
    Write-Error "Could not start process $msiExec."
    $exitCode = -1
}
else {
    Write-Host "Process returned exit code: $($process.ExitCode)"
    # We return 0 if we managed to start the process, even if it crashed.
    $exitCode = 0
}
return $exitCode
